﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace YieldCalculator
{
   
    public class Bond
    {
        [JsonProperty("id")]
        public string Id { get; set; }
        [JsonProperty("type")]
        public string Type { get; set; }
        [JsonProperty("tenor")]
        public string Tenor { get; set; }
        public decimal TenorDerived { get; set; }
        [JsonProperty("yield")]
        public string Yield { get; set; }
       
        public decimal YieldDerived { get; set; }
        [JsonProperty("amount_outstanding")]
        public int Amount_outstanding { get; set; }
        public decimal Spread { get; set; }
        public string GovermentBondId { get; set; }
        public int BasisPoints { get; set; }

        public bool IsValid { get; set; }

        
    }

  

}
