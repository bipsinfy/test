﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace YieldCalculator
{
    public static class Helpercs
    {   const string tenorSeperator= " ";
        const string yieldSeperator = "%";
        public static Bond ValidateBond(Bond bond)
        {   
             
            bool valid = true;
            if (bond==null) throw new ArgumentException(nameof(bond));

            if (bond.Id == null || string.IsNullOrEmpty(bond.Tenor) || string.IsNullOrEmpty(bond.Type) || string.IsNullOrEmpty(bond.Yield) || bond.Amount_outstanding == 0)
            {
                valid = false;
            }

            if (bond.Type == "government" || bond.Type == "corporate")
            {
            }
            else
                valid = false;
            string[] tenorTmp = bond.Tenor?.Split(tenorSeperator);
            decimal.TryParse(tenorTmp[0], out decimal tmpTenor);
            bond.TenorDerived = tmpTenor;
            if (bond.Yield != null)
            {
                string[] yieldTmps = bond.Yield.Split(yieldSeperator);
                decimal.TryParse(yieldTmps[0], out decimal tmpYield);
                bond.YieldDerived = tmpYield;
            }
            
            bond.IsValid = valid;
            return bond;

        }
    }
}
