﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace YieldCalculator
{
    public class OutPutBond
    {
        [JsonProperty("corporate_bond_id")]
        public string CorporareBondId { get; set; }
        [JsonProperty("government_bond_id")]
        public string GovernmentBondId { get; set; }
        [JsonProperty("spread_to_benchmark")]
        public string SpreadToBenchmark { get; set; }

        public static explicit operator OutPutBond(Bond bond)
        {
            OutPutBond outPutBond = new OutPutBond();
            outPutBond.CorporareBondId = bond.Id;
            outPutBond.GovernmentBondId = bond.GovermentBondId;
            outPutBond.SpreadToBenchmark = bond.Spread.ToString() + " bps";
            return outPutBond;
        }
    }

   
}
