﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using YieldCalculator;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFIle;//= args[0];
            string outputFIle;// = args[1];

            inputFIle = @"C:\Users\Administrator\Documents\GitHub\sde-test\sample_input.json";
            outputFIle = @"C:\Users\Administrator\Documents\GitHub\sde-test\sample_output2.json";


            // read JSON directly from a file       
            List<Bond> validatedBonds = new List<Bond>();

            BondsJson bondsJson = JsonConvert.DeserializeObject<BondsJson>(File.ReadAllText(inputFIle));

            for (int i = 0; i < bondsJson.Bonds.Length; i++)
            {
                Bond validatedBond = Helpercs.ValidateBond(bondsJson.Bonds[i]);
                if (validatedBond.IsValid)
                    validatedBonds.Add(validatedBond);
            }

            var corpBonds = from bondV in validatedBonds where bondV.Type == "corporate" select bondV;
            var govBonds = from bondV in validatedBonds where bondV.Type == "government" select bondV;
            List<OutPutBond> outputBonds = new List<OutPutBond>();

            int outputBondCounter = 0;
            foreach (var currrentcorporateBond in corpBonds)
            {
                var closestGovermentBond = govBonds.OrderBy(item => Math.Abs(currrentcorporateBond.YieldDerived - item.YieldDerived)).ThenBy(a => a.Amount_outstanding).First();
                currrentcorporateBond.BasisPoints = (int)Math.Abs(closestGovermentBond.YieldDerived - currrentcorporateBond.YieldDerived) * 100;
                currrentcorporateBond.Spread = Math.Abs(closestGovermentBond.YieldDerived - currrentcorporateBond.YieldDerived);
                currrentcorporateBond.GovermentBondId = closestGovermentBond.Id;
                outputBonds.Add((OutPutBond)currrentcorporateBond);
                outputBondCounter++;
            }
            BondsOutPutJson bondsOutPutJson = new BondsOutPutJson();
            bondsOutPutJson.Bonds = outputBonds.ToArray();
            File.WriteAllText(outputFIle, JsonConvert.SerializeObject(bondsOutPutJson));
           
        }
    }

    [DataContract]
    public class BondsJson
    {
        [JsonProperty("data")]
        public Bond[] Bonds { get; set; }
    }

    [DataContract]
    public class BondsOutPutJson
    {
        [JsonProperty("data")]
        public OutPutBond[] Bonds { get; set; }
    }
}
